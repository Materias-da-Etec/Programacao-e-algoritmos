"""
Descrição: Leia dois números e imprima o maior deles
Parâmetros: Os números digitados pelo usuário
Valores de saída: O maior entre os dois valores
Autor: Marcos Vinicius da Silva
"""

num1 = int(input("Digite primeiro número: "))
num2 = int(input("Digite segundo número: "))
maior_num=num1 if num1>num2 else num2
print(f"O maior número será {maior_num}")