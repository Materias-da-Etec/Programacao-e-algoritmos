"""
Descrição: Leia o turno de um estudante
e imprima 'bom dia' ou 'boa tarde' ou 'boa noite'
ou 'valor inválido' 
Parâmetros: O turno do aluno 
Valores de saída: Uma saudação de acordo com turno
Autor: Marcos Vinicius da Silva
"""

turno = str(input("Digite seu turno de estudo[M/V/N]: "))
if turno.upper() =="M":
    print("Bom dia!")
elif turno.upper()=="V":
    print("Boa tarde!")
elif turno.upper()=="N":
    print("Boa noite!")
else:
    print("Valor inválido!")