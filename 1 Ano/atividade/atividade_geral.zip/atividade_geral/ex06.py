"""
Descrição: O quadrado de valores inteiros
entre 15 a 200
Parâmetros: O número que usuário digitar
Valores de saída: O valor digitado
pelo usuário ao quadrado
Autor: Marcos Vinicius da Silva
"""

num = int(input("Digite um valor: "))
if num>=15 and num<=200:
    quadrado=num*num
    print(f"O quadrado do número {num} será {quadrado}")