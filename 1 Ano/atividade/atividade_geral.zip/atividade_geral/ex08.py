"""
Descrição: Soma dos 100 primeiros
números naturais 
Parâmetros: Nenhum
Valores de saída: A soma dos primeiros 100 números
Autor: Marcos Vinicius da Silva
"""
soma=0
for i in range(101):
    soma+=i
print(f"A soma dos 100 primeiros números será {soma}")