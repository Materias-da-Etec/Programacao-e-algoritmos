"""
Descrição: Somatório de números par de 1 a 500
Parâmetros: Nenhum
Valores de saída: A soma dos números
pares de 0 a 500
Autor: Marcos Vinicius da Silva
"""

soma=0
for i in range(501):
    if  i%2==0:
        soma+=i

print(f"O somatório de valores par existentes entre 1 e 500 {soma}")