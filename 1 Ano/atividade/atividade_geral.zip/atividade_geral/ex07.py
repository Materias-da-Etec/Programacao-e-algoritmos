"""
Descrição: Leia um número e imprima sua tabuada
Parâmetros: Um número digitado pelo usuário
Valores de saída: A tabuada do número
digitado pelo usuário
Autor: Marcos Vinicius da Silva
"""

num=int(input("Digite um valor: "))
for i in range(1,11):
    mult=num*i
    print(f"{num}X{i} = {mult}")