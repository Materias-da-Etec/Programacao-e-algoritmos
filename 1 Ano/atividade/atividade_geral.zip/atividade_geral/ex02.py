"""
Descrição: Leia um número e verifique
se é positivo ou negativo
Parâmetros: O número digitado pelo usuário
Valores de saída: O valor positivo ou negativo
Autor: Marcos Vinicius da Silva
"""

num1= int(input("Digite um valor: "))
if num1<0:
    print(f"O número {num1} é negativo")
else:
    print(f"O número {num1} é positivo")
    