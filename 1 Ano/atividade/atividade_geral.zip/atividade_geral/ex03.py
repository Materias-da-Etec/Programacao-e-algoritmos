"""
Descrição: Leia o sexo de uma pessoa e 
verifique se é masculino ou feminino
Parâmetros: O sexo da pessoa
Valores de saída: O sexo da pessoa
Autor: Marcos Vinicius da Silva
"""

sexo= str(input("Digite seu sexo [F/M]: "))
if sexo.upper() =="F":
    print("Seu sexo é feminino")
elif sexo.upper() =="M":
    print("Seu sexo é masculino")
else:
    print("Sexo inválido")