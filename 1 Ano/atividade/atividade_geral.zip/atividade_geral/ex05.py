"""
Descrição: Leia as notas, faça média
de um aluno e verifique sua situação
Parâmetros: Notas do aluno
Valores de saída: A situação do aluno
Autor: Marcos Vinicius da Silva
"""

primeira_nota=float(input("Digite a primeira nota: "))
segunda_nota=float(input("Digite a segunda nota: "))
media=(primeira_nota+segunda_nota)/2

if media>=7:
    print("Aprovado")
elif media<7:
    print("Reprovado")
elif media==10:
    print("Aprovado com Distinção")