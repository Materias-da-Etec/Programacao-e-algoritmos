"""
Descrição: Valores ímpares de 0 a 20
Parâmetros: Nenhum
Valores de saída: Valores ímpares de 1 a 20
Autor: Marcos Vinicius da Silva
"""

for i in range(21):
    if i%2==1:
        print(i,end=" ")